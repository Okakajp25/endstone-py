from endstone_example.example_plugin import ExamplePlugin

__all__ = ["ExamplePlugin"]
